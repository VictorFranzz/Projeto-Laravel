<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class filme extends Model
{
    //
}
